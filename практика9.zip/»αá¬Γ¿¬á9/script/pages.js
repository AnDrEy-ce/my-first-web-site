'use strict'
document.querySelector('.mainUl').addEventListener('click',show)
document.addEventListener('click', hide);
function hide(event) { 
    if(event.target != document.querySelector('li.forUnNone') && (event.target != document.querySelector('i.fa.fa-search')) && (event.target != document.querySelector('li.forUnNoneTwo')))    {
        document.querySelector('.forFound').setAttribute('id','catalog')
    }
}
function show(event) {
    let parent = event.currentTarget
    parent.querySelector('#catalog').setAttribute('id','show')
}
let cart =[];
let favorite =[];
let tbody = document.querySelector('tbody')
class Product{
    constructor(name,img,price){
        this.name=name;
        this.img=img;
        this.price=price;
        this.count=1;
    }
}
document.querySelectorAll('.moveCart').forEach(item => item.addEventListener('click',MoveToCart))


function MoveToCart(event) {
    let parent = event.target.closest('.card');
    let name = parent.querySelector('.card-title').innerText;
    let img = parent.querySelector('img').getAttribute('src');
    let price = parent.querySelector('.defolt-price').innerText;
    let elem = cart.find(item => item.name == name);
    if(elem){
        elem.count++
    }else{
        cart.push(new Product(name,img,price))
    }
}
document.querySelector('a i.fa.fa-shopping-cart').addEventListener('click',ShowCart)
document.querySelector('.toCartForPhone').addEventListener('click',ShowCart)
function ShowCart(event) {
    tbody.innerHTML='';
    cart.forEach(function(item,index) {
        tbody.insertAdjacentHTML('beforeend',`
        <tr>
        <td class="center-left">${index+1}</td>
        <td>${item.name}</td>
        <td><img src=${item.img} class='imgCart'></td>
        <td>${item.price}</td>
        <td>${item.count}</td>
        <td class="center-right"><i class="fa fa-trash" aria-hidden="true"></i></td>
      </tr>
        `)
        document.querySelectorAll('.fa-trash').forEach(item =>item.addEventListener('click',remove))
    }
    )
}
function remove(event) {
    let parent = event.target.closest('tr')
    let name = parent.querySelector('td:nth-child(2n)').innerText
    let index = cart.findIndex(item => item.name==name)
    cart.splice(index,1)
    parent.remove();
}


function removeFromFavorite(event) {
    let parent = event.target.closest('.card')
    let name = parent.querySelector('.card-title').innerText
    let index = favorite.findIndex(item => item.name==name)
    favorite.splice(index,1)
   
}
document.querySelectorAll('.fa-heart-o:not(.header)').forEach(item => item.addEventListener('click',toFavorite))
document.querySelectorAll('.fa-heart:not(.footer)').forEach(item => item.addEventListener('click',toFavorite))
document.querySelectorAll('.fa-heart-o:not(.header)').forEach(item => item.addEventListener('click',toFavoritePc))
document.querySelectorAll('.fa-heart:not(.footer)').forEach(item => item.addEventListener('click',toFavoritePc))
document.querySelectorAll('.fa-heart:not(.footer)').forEach(item => item.addEventListener('click',removeFromFavorite))

function toFavorite(event) {
    let parent = event.target.closest('.card');
    let name = parent.querySelector('.card-title').innerText;
    let img = parent.querySelector('img').getAttribute('src');
    let price = parent.querySelector('.defolt-price').innerText;
    let elem = favorite.find(item => item.name == name);
    if(elem){
        elem.count++
    }else{
        favorite.push(new Product(name,img,price))
    }
    if(event.target.classList.contains('fa-heart-o')){
        event.target.closest('.MoveToCart').querySelector('.fa-heart').classList.remove('none')
        event.target.classList.add('none')

        
    }
    if(event.target.classList.contains('fa-heart')){
        event.target.closest('.MoveToCart').querySelector('.fa-heart-o').classList.remove('none')
        event.target.classList.add('none')
        
    }

}
function toFavoritePc(event) {
    let parent = event.target.closest('.card');
    let name = parent.querySelector('.card-title').innerText;
    let img = parent.querySelector('img').getAttribute('src');
    let price = parent.querySelector('.defolt-price').innerText;
    let elem = favorite.find(item => item.name == name);
    if(elem){
        elem.count++
    }else{
        favorite.push(new Product(name,img,price))
    }
    if(event.target.classList.contains('fa-heart-o')){
        event.target.closest('.priceCamera').querySelector('.fa-heart').classList.remove('none')
        event.target.classList.add('none')

        
    }
    if(event.target.classList.contains('fa-heart')){
        event.target.closest('.priceCamera').querySelector('.fa-heart-o').classList.remove('none')
        event.target.classList.add('none')
        
    }

}
document.querySelectorAll('.show-filter-brand').forEach(item => item.addEventListener('click',showFilter))

function showFilter(event){
    // let parent = event.target.closest('.filter');
    let parent = event.currentTarget.previousElementSibling;
    parent.classList.add('notHidden');
    event.target.classList.add('none');
}
document.querySelectorAll('.hide-filter-brand').forEach(item => item.addEventListener('click',hideFilter))
function hideFilter(event) {
    // let parent = event.target.closest('.filter');
    let parent = event.target.closest('.filter-brand').nextElementSibling;
    parent.querySelector('a').classList.remove('none');
    event.target.closest('.filter-brand').classList.remove('notHidden');
}






document.querySelector('.fa-heart-o').addEventListener('click',showFavorite)
document.querySelector('.footer').addEventListener('click',showFavorite)
function showFavorite(event) {
    let tbody = document.querySelector('.table-favorite tbody')
    tbody.innerHTML='';
    favorite.forEach(function(item,index) {
        tbody.insertAdjacentHTML('beforeend',`
        <tr>
        <td class="center-left">${index+1}</td>
        <td>${item.name}</td>
        <td><img src=${item.img} class='imgCart'></td>
        <td>${item.price}</td>
        <td>${item.count-1}</td>
      </tr>
        `)
       
    }
    )

}

document.querySelector('.filter-phone').addEventListener('click',showFilterForPhone)
function showFilterForPhone(event){
    event.target.nextElementSibling.classList.remove('none')
    event.target.classList.add('none')
}
document.querySelector('.fa-times').addEventListener('click',hideFilterForPhone)
function hideFilterForPhone(event) {
    event.target.closest('.filter-for-phone').previousElementSibling.classList.remove('none')
    event.target.closest('.filter-for-phone').classList.add('none')
}


let filters = [];

let cards = document.querySelectorAll('.card');

let checkbox = document.querySelectorAll('.filter-brand input')

checkbox.forEach(item => item.addEventListener('click',filter))

function filter(event) {
   
    if(event.target.checked == true){
       filters.push(event.target)
    }else{
        let elem = event.target.dataset['brand'];
        let ind = filters.findIndex(item => item.dataset['brand'] == elem);
        filters.splice(ind,1)
    }
    cards.forEach(item => item.classList.add('none'))

    cards.forEach(item => {
        let filterbrand = item.dataset['brand'];
        let ind = filters.findIndex(item => item.dataset['brand'] == filterbrand)
        if(ind != -1){
            item.classList.remove('none');
        }  
    });


    if(filters.length == 0){
       cards.forEach(item => item.classList.remove('none'))
    }
}
    

























































// document.querySelectorAll('.filter-brand').forEach(item => item.addEventListener('click',showBrand))
// function showBrand(event){
//    let q = event.target.dataset.brand


//    if(event.target.checked == true){
//        let brand = event.target.dataset.brand
//     //    document.querySelectorAll('.card').forEach(item => item.classList.add('none'))
//         switch (brand) {
//             case 'asusu':
//                 document.querySelectorAll('.card').forEach(item => {
//                 if(item.dataset.brand == 'asusu'){
//                     item.classList.remove('none')
//                 }                                            
//             })                                            
//                 break;
        
//             case 'hononor':
//             document.querySelectorAll('.card').forEach(item => { 
//             if(item.dataset.brand == 'hononor'){
//                 item.classList.remove('none')
//             }                                            
//         })         
//                 break;
//                 case 'aplele':
//                 document.querySelectorAll('.card').forEach(item => {
//                 if(item.dataset.brand == 'aplele'){
//                     item.classList.remove('none')
//                 }                                            
//             })                                            
//                 break;
//         }



//    }else{

//    }


// }