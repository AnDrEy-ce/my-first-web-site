const range = document.getElementById('filterSlider')
// создание самого слайдера - ползунка
if(range){
noUiSlider.create(range, {
    start: [500, 999999],
    connect: true,
    step: 500,
    range: {
        'min': [500],
        'max': [999999]
    }
});
// создние input
const input0 = document.getElementById('input-0');
const input1 = document.getElementById('input-1');
const input = [input0,input1];
// value - значение,handle - левый или правый,1 или 0,нужно для тог чтобы связать input и полунок
range.noUiSlider.on('update',function(values,handle){
input[handle].value = Math.round(values[handle])
});
// создание функции чтобы при вводе в input менялся и ползунок
const setRangeSlider = (item,value) =>{
    let arr = [null,null];
    arr[item] = value;
    range.noUiSlider.set(arr)
}
// на каждый input вешаем событие change(работает при отпущене ползунка)
input.forEach((item,index) =>{
item.addEventListener('change',event =>{
    setRangeSlider(index,event.currentTarget.value)
        });
    });
}


const range2 = document.getElementById('filterSlider-2')
// создание самого слайдера - ползунка
if(range2){
noUiSlider.create(range2, {
    start: [500, 999999],
    connect: true,
    step: 500,
    range: {
        'min': [500],
        'max': [999999]
    }
});
// создние input
const input0Two = document.getElementById('input-0-2');
const input1Two = document.getElementById('input-1-2');
const inputTwo = [input0Two,input1Two];
// value - значение,handle - левый или правый,1 или 0,нужно для тог чтобы связать input и полунок
range2.noUiSlider.on('update',function(values,handle){
inputTwo[handle].value = Math.round(values[handle])
});
// создание функции чтобы при вводе в input менялся и ползунок
const setRangeSlider2 = (item,value) =>{
    let arr2 = [null,null];
    arr2[item] = value;
    range2.noUiSlider.set(arr2)
}
// на каждый input вешаем событие change(работает при отпущене ползунка)
inputTwo.forEach((item,index) =>{
item.addEventListener('change',event =>{
    setRangeSlider2(index,event.currentTarget.value)
        });
    });
}





